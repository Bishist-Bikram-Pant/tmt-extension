/**
 * Popup Script
 * Handles user interactions in the extension popup
 * Note: CONFIG is loaded as a global from config.js script
 */

class PopupController {
  constructor() {
    this.currentTab = null;
    this.isTranslating = false;
    this.elementCache = new Map();
    this.isRestrictedPage = false;
    this.initializeElements();
    this.setupEventListeners();
    this.initializeTab();
  }

  /**
   * Initialize the current tab and check if it's accessible
   */
  async initializeTab() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      this.currentTab = tab;
      
      // Check if page is restricted (chrome://, about://, file://, etc.)
      if (!tab || !tab.url || tab.url.startsWith('chrome://') || 
          tab.url.startsWith('about:') || tab.url.startsWith('edge://')) {
        this.isRestrictedPage = true;
        this.elements.translateBtn.disabled = true;
        this.elements.resetBtn.disabled = true;
        this.showError('Cannot translate restricted pages');
        return;
      }
      
      this.isRestrictedPage = false;
      await this.updateStatus();
    } catch (error) {
      console.error('[Popup] Error initializing tab:', error);
      this.isRestrictedPage = true;
      this.elements.translateBtn.disabled = true;
      this.elements.resetBtn.disabled = true;
    }
  }

  /**
   * Cache DOM elements for frequent access
   */
  initializeElements() {
    this.elements = {
      sourceLang: document.getElementById('sourceLang'),
      targetLang: document.getElementById('targetLang'),
      swapBtn: document.getElementById('swapLangs'),
      translateBtn: document.getElementById('translateBtn'),
      cancelBtn: document.getElementById('cancelBtn'),
      resetBtn: document.getElementById('resetBtn'),
      progressSection: document.getElementById('progressSection'),
      progressFill: document.getElementById('progressFill'),
      progressText: document.getElementById('progressText'),
      errorMessage: document.getElementById('errorMessage'),
      successMessage: document.getElementById('successMessage')
    };
  }

  /**
   * Setup event listeners for UI interactions
   */
  setupEventListeners() {
    this.elements.translateBtn.addEventListener('click', () => this.handleTranslate());
    this.elements.cancelBtn.addEventListener('click', () => this.handleCancel());
    this.elements.resetBtn.addEventListener('click', () => this.handleReset());
    this.elements.swapBtn.addEventListener('click', () => this.handleSwapLanguages());

    // Auto-update on language selection change
    this.elements.sourceLang.addEventListener('change', () => this.validateLanguagePair());
    this.elements.targetLang.addEventListener('change', () => this.validateLanguagePair());
  }

  /**
   * Validate language pair is supported
   */
  validateLanguagePair() {
    const src = this.elements.sourceLang.value;
    const tgt = this.elements.targetLang.value;

    if (src === tgt) {
      this.showError('Source and target languages must be different');
      this.elements.sourceLang.value = 'en';
      this.elements.targetLang.value = 'ne';
      return false;
    }

    const isValid = CONFIG.TRANSLATION_PAIRS.some(
      pair => pair.from === src && pair.to === tgt
    );

    if (!isValid) {
      this.showError(`Translation pair ${src} → ${tgt} is not supported`);
      this.elements.targetLang.value = 'ne';
      return false;
    }

    return true;
  }

  /**
   * Handle translate button click
   */
  async handleTranslate() {
    if (this.isRestrictedPage) {
      this.showError('Cannot translate restricted pages');
      return;
    }

    if (!this.validateLanguagePair()) {
      return;
    }

    const srcLang = this.elements.sourceLang.value;
    const tgtLang = this.elements.targetLang.value;

    if (this.isTranslating) {
      this.showError('Translation already in progress');
      return;
    }

    this.isTranslating = true;
    this.toggleButtons(true);
    this.showProgress(true);
    this.clearMessages();

    try {
      console.log(`[Popup] Starting translation: ${srcLang} → ${tgtLang}`);

      // Get current active tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      this.currentTab = tab;

      // Send translation command to content script
      const response = await this.sendMessage({
        action: 'START_TRANSLATION',
        srcLang: srcLang,
        tgtLang: tgtLang
      });

      if (response.success) {
        this.showSuccess('Page translation started successfully!');
        this.updateStatus();
      } else {
        this.showError('Failed to start translation: ' + response.error);
      }
    } catch (error) {
      console.error('[Popup] Translation error:', error);
      this.showError('Translation error: ' + error.message);
    } finally {
      this.isTranslating = false;
      this.toggleButtons(false);
      this.showProgress(false);
    }
  }

  /**
   * Handle reset button click - resets page to original content
   */
  async handleReset() {
    if (this.isRestrictedPage) {
      this.showError('Cannot reset restricted pages');
      return;
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      await this.sendMessage({ action: 'RESTORE_ORIGINAL_PAGE' });
      this.showSuccess('Page has been restored to original content');
      this.updateStatus();
    } catch (error) {
      console.error('[Popup] Reset error:', error);
      this.showError('Failed to reset page: ' + error.message);
    }
  }

  /**
   * Handle cancel button click
   */
  async handleCancel() {
    try {
      this.showProgress(false);
      this.showSuccess('Translation cancelled');
      this.isTranslating = false;
      this.toggleButtons(false);
      this.updateStatus();
    } catch (error) {
      console.error('[Popup] Cancel error:', error);
      this.showError('Failed to cancel: ' + error.message);
    }
  }

  /**
   * Handle swap languages button click
   */
  handleSwapLanguages() {
    const src = this.elements.sourceLang.value;
    const tgt = this.elements.targetLang.value;

    this.elements.sourceLang.value = tgt;
    this.elements.targetLang.value = src;

    this.validateLanguagePair();
  }

  /**
   * Toggle between Translate and Cancel buttons
   */
  toggleButtons(isTranslating) {
    if (isTranslating) {
      this.elements.translateBtn.style.display = 'none';
      this.elements.cancelBtn.style.display = 'block';
    } else {
      this.elements.translateBtn.style.display = 'block';
      this.elements.cancelBtn.style.display = 'none';
    }
  }

  /**
   * Send message to content script
   */
  async sendMessage(message) {
    return new Promise((resolve, reject) => {
      if (!this.currentTab || !this.currentTab.id) {
        reject(new Error('No active tab found'));
        return;
      }

      // Double-check if page is restricted
      if (!this.currentTab.url || this.currentTab.url.startsWith('chrome://') || 
          this.currentTab.url.startsWith('about:') || this.currentTab.url.startsWith('edge://')) {
        reject(new Error('Cannot translate restricted pages (chrome://, about:, etc.)'));
        return;
      }

      console.log(`[Popup] Sending message to tab ${this.currentTab.id}:`, message.action);
      
      chrome.tabs.sendMessage(this.currentTab.id, message, (response) => {
        if (chrome.runtime.lastError) {
          const errorMsg = chrome.runtime.lastError.message;
          console.error('[Popup] Tab message error:', errorMsg);
          
          // Provide helpful error messages
          if (errorMsg.includes('Could not establish connection')) {
            reject(new Error('Content script not loaded. Try refreshing the page.'));
          } else if (errorMsg.includes('Receiving end does not exist')) {
            reject(new Error('Cannot access this page type. Try another page.'));
          } else {
            reject(new Error(errorMsg));
          }
        } else if (!response) {
          console.error('[Popup] No response from content script');
          reject(new Error('Content script not responding. Try refreshing the page.'));
        } else {
          console.log('[Popup] Response received:', response);
          resolve(response);
        }
      });
    });
  }

  /**
   * Update status display
   */
  async updateStatus() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      this.currentTab = tab;

      // Check if page is restricted
      if (!tab.url || tab.url.startsWith('chrome://') || 
          tab.url.startsWith('about:') || tab.url.startsWith('edge://') ||
          tab.url.startsWith('file://')) {
        this.isRestrictedPage = true;
        this.elements.translateBtn.disabled = true;
        this.elements.resetBtn.disabled = true;
        return;
      }

      this.isRestrictedPage = false;
      this.elements.resetBtn.disabled = false;

      // Get page status from content script with error handling
      const response = await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          resolve({ isTranslating: false, elementCount: 0 });
        }, 2000); // 2 second timeout

        chrome.tabs.sendMessage(tab.id, { action: 'GET_PAGE_STATUS' }, (response) => {
          clearTimeout(timeout);
          if (chrome.runtime.lastError) {
            console.log('[Popup] Could not get page status:', chrome.runtime.lastError.message);
            resolve({ isTranslating: false, elementCount: 0 });
          } else {
            resolve(response || { isTranslating: false, elementCount: 0 });
          }
        });
      });

      // Update button state
      if (response.isTranslating) {
        this.elements.translateBtn.disabled = true;
      } else {
        this.elements.translateBtn.disabled = false;
      }
    } catch (error) {
      console.log('[Popup] Error updating status:', error);
      this.elements.translateBtn.disabled = false;
    }
  }

  /**
   * Show progress indicator
   */
  showProgress(show) {
    if (show) {
      this.elements.progressSection.classList.add('show');
      this.elements.progressText.textContent = 'Translating... Please wait';
    } else {
      this.elements.progressSection.classList.remove('show');
    }
  }

  /**
   * Show error message
   */
  showError(message) {
    this.elements.errorMessage.textContent = message;
    this.elements.errorMessage.classList.add('show');
    this.elements.successMessage.classList.remove('show');

    setTimeout(() => {
      this.elements.errorMessage.classList.remove('show');
    }, 5000);
  }

  /**
   * Show success message
   */
  showSuccess(message) {
    this.elements.successMessage.textContent = message;
    this.elements.successMessage.classList.add('show');
    this.elements.errorMessage.classList.remove('show');

    setTimeout(() => {
      this.elements.successMessage.classList.remove('show');
    }, 5000);
  }

  /**
   * Clear all messages
   */
  clearMessages() {
    this.elements.errorMessage.classList.remove('show');
    this.elements.successMessage.classList.remove('show');
  }
}

// Initialize popup controller when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  console.log('[Popup] Initializing popup controller');
  new PopupController();
});
